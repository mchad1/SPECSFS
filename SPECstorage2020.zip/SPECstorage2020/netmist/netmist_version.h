#ifndef _NETMIST_VERSION_H_
#define _NETMIST_VERSION_H_

extern char *git_date;
extern char *git_sha;
extern char *git_version;

#endif
