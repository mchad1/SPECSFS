#include "netmist_version.h"
char *git_date = "Tue Mar 16 08:33:11 CDT 2021";
char *git_sha = "849bce769b069f7570d073e5248cb7f15e575fa7";
char *git_version = "$Revision: 2512 $";
